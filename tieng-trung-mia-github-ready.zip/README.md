# TIẾNG TRUNG MIA — GitHub Pages Ready

Bản này đã sửa để upload lên GitHub/GitHub Pages chạy trực tiếp.

## Cách dùng nhanh
1. Upload toàn bộ nội dung trong file ZIP này lên repository GitHub.
2. Vào Settings → Pages.
3. Source: Deploy from a branch.
4. Branch: main, folder: /root.
5. Mở link GitHub Pages.

## Lưu ý
- File `index.html` ở thư mục gốc đã dùng đường dẫn tương đối `./assets/...`, phù hợp khi GitHub Pages chạy trong dạng `username.github.io/ten-repo/`.
- Thư mục `source-code/` là mã nguồn React/Vite để sửa tiếp nếu cần.
- Nếu build lại trong `source-code`, cấu hình Vite đã thêm `base: './'` để không bị lỗi trắng trang trên GitHub Pages.
